config.json is your bot configuration.
